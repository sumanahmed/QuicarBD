</div>	
    <!-- jQuery -->
    <script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>    
	<!-- Data table JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('quicarbd/admin/dist/js/dataTables-data.js')); ?>"></script>	
	<!-- Slimscroll JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/dist/js/jquery.slimscroll.js')); ?>"></script>	
	<!-- Progressbar Animation JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
	<script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/jquery.counterup/jquery.counterup.min.js')); ?>"></script>	
	<!-- Fancy Dropdown JS -->
	<script src="<?php echo e(asset('quicarbd/admin/dist/js/dropdown-bootstrap-extended.js')); ?>"></script>	
	<!-- Sparkline JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/vendors/jquery.sparkline/dist/jquery.sparkline.min.js')); ?>"></script>	
	<!-- Owl JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>	
	<!-- Switchery JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/switchery/dist/switchery.min.js')); ?>"></script>	
	<!-- EChartJS JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/echarts/dist/echarts-en.min.js')); ?>"></script>
	<script src="<?php echo e(asset('quicarbd/admin/vendors/echarts-liquidfill.min.js')); ?>"></script>	
	<!-- Dropify JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/dropify/dist/js/dropify.min.js')); ?>"></script>	
	<!-- Toast JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js')); ?>"></script>	
	<!-- Init JavaScript -->
	<script src="<?php echo e(asset('quicarbd/admin/dist/js/init.js')); ?>"></script>
	<script src="<?php echo e(asset('quicarbd/admin/dist/js/dashboard-data.js')); ?>"></script>
	<script>
		var image_base_path = "http://quicarbd.com/";
		//var image_base_path = "http://localhost:8000/";
	</script>
	<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH E:\Laravel Projects\QuicarBD\resources\views/quicarbd/admin/inc/footer_bottom.blade.php ENDPATH**/ ?>