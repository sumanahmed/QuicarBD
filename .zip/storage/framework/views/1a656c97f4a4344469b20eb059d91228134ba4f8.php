<?php echo $__env->make('quicarbd.admin.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('quicarbd.admin.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-wrapper">
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('quicarbd.admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php echo $__env->make('quicarbd.admin.inc.footer_bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH E:\Laravel Projects\QuicarBD\resources\views/quicarbd/admin/layout/admin.blade.php ENDPATH**/ ?>