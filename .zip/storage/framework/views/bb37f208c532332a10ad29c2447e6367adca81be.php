<footer class="footer container-fluid pl-30 pr-30">
    <div class="row">
        <div class="col-sm-12">
            <p>2018 &copy; Goofy. Pampered by Hencework</p>
        </div>
    </div>
</footer><?php /**PATH E:\Laravel Projects\QuicarBD\resources\views/quicarbd/admin/inc/footer.blade.php ENDPATH**/ ?>