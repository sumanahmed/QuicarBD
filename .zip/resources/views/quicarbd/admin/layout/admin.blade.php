@include('quicarbd.admin.inc.header')
@include('quicarbd.admin.inc.sidebar')

<div class="page-wrapper">
    @yield('content')
    @include('quicarbd.admin.inc.footer')
</div>

@include('quicarbd.admin.inc.footer_bottom')

