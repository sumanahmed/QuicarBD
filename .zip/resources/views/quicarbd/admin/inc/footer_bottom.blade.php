</div>	
    <!-- jQuery -->
    <script src="{{ asset('quicarbd/admin/vendors/bower_components/jquery/dist/jquery.min.js') }}"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="{{ asset('quicarbd/admin/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>    
	<!-- Data table JavaScript -->
	<script src="{{ asset('quicarbd/admin/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js') }}"></script>
	<script src="{{ asset('quicarbd/admin/dist/js/dataTables-data.js') }}"></script>	
	<!-- Slimscroll JavaScript -->
	<script src="{{ asset('quicarbd/admin/dist/js/jquery.slimscroll.js') }}"></script>	
	<!-- Progressbar Animation JavaScript -->
	<script src="{{ asset('quicarbd/admin/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js') }}"></script>
	<script src="{{ asset('quicarbd/admin/vendors/bower_components/jquery.counterup/jquery.counterup.min.js') }}"></script>	
	<!-- Fancy Dropdown JS -->
	<script src="{{ asset('quicarbd/admin/dist/js/dropdown-bootstrap-extended.js') }}"></script>	
	<!-- Sparkline JavaScript -->
	<script src="{{ asset('quicarbd/admin/vendors/jquery.sparkline/dist/jquery.sparkline.min.js') }}"></script>	
	<!-- Owl JavaScript -->
	<script src="{{ asset('quicarbd/admin/vendors/bower_components/owl.carousel/dist/owl.carousel.min.js') }}"></script>	
	<!-- Switchery JavaScript -->
	<script src="{{ asset('quicarbd/admin/vendors/bower_components/switchery/dist/switchery.min.js') }}"></script>	
	<!-- EChartJS JavaScript -->
	<script src="{{ asset('quicarbd/admin/vendors/bower_components/echarts/dist/echarts-en.min.js') }}"></script>
	<script src="{{ asset('quicarbd/admin/vendors/echarts-liquidfill.min.js') }}"></script>	
	<!-- Dropify JavaScript -->
	<script src="{{ asset('quicarbd/admin/vendors/bower_components/dropify/dist/js/dropify.min.js') }}"></script>	
	<!-- Toast JavaScript -->
	<script src="{{ asset('quicarbd/admin/vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js') }}"></script>	
	<!-- Init JavaScript -->
	<script src="{{ asset('quicarbd/admin/dist/js/init.js') }}"></script>
	<script src="{{ asset('quicarbd/admin/dist/js/dashboard-data.js') }}"></script>
	<script>
		var image_base_path = "http://quicarbd.com/";
		//var image_base_path = "http://localhost:8000/";
	</script>
	@yield('scripts')
</body>

</html>
